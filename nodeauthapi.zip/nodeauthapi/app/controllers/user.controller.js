exports.allAccess = (req, res) => {
  res.status(200).send("Hi Welcome all to SYRAHEALTH public health care service."+'\n\n'+"Syra Health is a healthcare company with a mission to improve healthcare by addressing some of the most significant healthcare challenges. Syra Health specializes in behavioral and mental health, digital health, and population health. Syra Health’s solutions are centered on prevention, improved access, and affordable care.");
};

exports.userBoard = (req, res) => {
  res.status(200).send("Welcome to syrahealth"+'\n'+"Hi Team, Syrahealth handles multiple projects."+'\n'+"Syra Health is a healthcare company with a mission to improve healthcare by addressing some of the most significant healthcare challenges. Syra Health specializes in behavioral and mental health, digital health, and population health. Syra Health’s solutions are centered on prevention, improved access, and affordable care.");
};

exports.adminBoard = (req, res) => {
  res.status(200).send("Admin Content.");
};

exports.moderatorBoard = (req, res) => {
  res.status(200).send("Moderator Content.");
};
